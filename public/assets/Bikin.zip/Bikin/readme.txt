Thanks for downloading this theme!

Theme Name: Bikin
Theme URL: https://bootstrapmade.com/bikin-free-simple-landing-page-template/
Author: BootstrapMade
Author URL: https://bootstrapmade.com